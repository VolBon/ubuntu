'''
Created on 29.10.2013

@author: vultuste
'''
import tai
def foo():
    
    tai.write("message from foo")
